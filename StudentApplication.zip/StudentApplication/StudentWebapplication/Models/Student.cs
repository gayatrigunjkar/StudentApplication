﻿using System.ComponentModel.DataAnnotations;

namespace StudentWebapplication.Models
{
    public class Student
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        [StringLength(100)]
        public string Course { get; set; }

        [Required]
        [StringLength(100)]
        public string College { get; set; }

        [Required]
        [StringLength(100)]
        public string HomeLocation { get; set; }
    }
}
